require(testthat)
require(RelimpPCR)
test_check("RelimpPCR")
